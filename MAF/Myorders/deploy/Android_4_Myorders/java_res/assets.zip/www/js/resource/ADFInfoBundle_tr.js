/* Copyright (c) 2011, 2012, Oracle and/or its affiliates. All rights reserved. */
/* ------------------------------------------------------ */
/* ------------------- ADFInfoBundle_tr.js ---------------------- */
/* ------------------------------------------------------ */
// AUTO-GENERATED FILE
// since this gets loaded programmatically, adf.mf.resource will already be defined

adf.mf.resource.ADFInfoBundle_tr={
"WARN_SKIP_REMOTE_WRITE":"Java kullan\u0131labilir olmad\u0131\u011f\u0131ndan uzak yazmay\u0131 atlayaca\u011f\u0131z.",
"LBL_WARNING_DISPLAY_STR":"Uyar\u0131",
"WARN_MESSAGE_FOR_SELENIUM_TEST":"{0} ba\u011f\u0131ms\u0131z de\u011fi\u015fkeni ile Selenium testi i\u00e7in uyar\u0131 mesaj\u0131",
"LBL_CONFIRMATION_DISPLAY_STR":"Teyit",
"LBL_INFO_DISPLAY_STR":"Bilgiler",
"WARN_PROCESSING_REMOVE_DATA_CHANGE":"#\'\'{{0}.collectionModel\'\'} i\u00e7in veri de\u011fi\u015fikli\u011fi (kald\u0131rma) i\u015flenirken bir sorun olu\u015ftu - {1}",
"WARN_PROCESSING_UPDATE_DATA_CHANGE":"#\'\'{{0}.collectionModel\'\'} i\u00e7in veri de\u011fi\u015fikli\u011fi (g\u00fcncelleme) i\u015flenirken bir sorun olu\u015ftu - {1}",
"LBL_OK_DISPLAY_STR":"Tamam",
"WARN_PROCESSING_CREATE_DATA_CHANGE":"#\'\'{{0}.collectionModel\'\'} i\u00e7in veri de\u011fi\u015fikli\u011fi (olu\u015fturma) i\u015flenirken bir sorun olu\u015ftu - {1}",
"LBL_FATAL_DISPLAY_STR":"Tehlikeli",
"WARN_PROCESSING_VAR_CHANGES":"{0} de\u011fi\u015fken de\u011fi\u015fiklikleri i\u015flenirken processDataChangeEvent hatas\u0131 olu\u015ftu",
"LBL_ERROR_DISPLAY_STR":"Hata",
"WARN_UNABLE_TO_FETCH_SET":"K\u00fcme getirilemiyor - {0}",
"WARN_PURGING_CACHE":"\u00d6nbellek temizlenmeye \u00e7al\u0131\u015f\u0131rken hata olu\u015ftu - {0}",
"WARN_UPDATING_CACHE":"Veri de\u011fi\u015fiklik olay\u0131n\u0131n sonucunda \u00f6nbellek g\u00fcncellenirken sorun olu\u015ftu.",
"WARN_PROCESSING_PROVIDER_CHANGES":"{0} sa\u011flay\u0131c\u0131 de\u011fi\u015fiklikleri i\u015flenirken processDataChangeEvent hatas\u0131 olu\u015ftu",
"oracle.core.ojdl.logging.MessageIdKeyResourceBundle":""
}
